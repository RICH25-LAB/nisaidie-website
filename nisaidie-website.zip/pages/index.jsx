
export default function Home() {
  return <h1>NISAIDIE NISOME INITIATIVE – Website Ready</h1>
}
